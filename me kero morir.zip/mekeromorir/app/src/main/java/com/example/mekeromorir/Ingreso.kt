package com.example.mekeromorir

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Ingreso : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ingreso)

        // Recibe el dato pasado desde MainActivity
        val stNombre = intent.getStringExtra("STNombre")

        // Muestra el nombre en el TextView correspondiente
        val textView: TextView = findViewById(R.id.textViewNombre) // Usar el ID correcto
        textView.text = stNombre ?: "Nombre no proporcionado"
    }
}
