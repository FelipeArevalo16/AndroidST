package com.example.mekeromorir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa el botón después de configurar el contenido
        val bTConectarse: Button = findViewById(R.id.BTConectarse)
        bTConectarse.setOnClickListener {
            val eTNombre: EditText = findViewById(R.id.ETNombreUsuario)
            val stNombre: String = eTNombre.text.toString()

            // Crea el Intent y pasa el nombre a la actividad Ingreso
            val sIntent = Intent(this, Ingreso::class.java)
            sIntent.putExtra("STNombre", stNombre)
            startActivity(sIntent)
        }
    }
}
